//
//  DisplayTimeViewCell.swift
//  StopWatch
//
//  Created by Kien on 12/13/17.
//  Copyright © 2017 Kien. All rights reserved.
//

import UIKit

class DisplayTimeViewCell: UITableViewCell {

    @IBOutlet weak var timeLabLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
